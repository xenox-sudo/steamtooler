import tkinter as tk
import json
import os
import sys
import os
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(ROOT)

from core.detect_steam_installation import find_steam, save_config
from core.injector import injector

# dossier racine du projet
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG = os.path.join(ROOT, "config")

os.makedirs(CONFIG, exist_ok=True)

CONFIG_FILE = os.path.join(CONFIG, "config.json")


ui = tk.Tk()
ui.title("Configuration UI")
ui.geometry("900x900")
ui.resizable(False, False)


widgets_theme = []


def save_theme(theme):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump({"theme": theme}, f, indent=4)


def appliquer_theme(bg, fg):
    ui.configure(bg=bg)

    for widget in widgets_theme:
        widget.configure(
            bg=bg,
            fg=fg
        )


def set_theme_black():
    save_theme("black")
    appliquer_theme("black", "white")


def set_theme_white():
    save_theme("white")
    appliquer_theme("white", "black")

def load_theme():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                config = json.load(f)
                theme = config.get("theme", "white")
                if theme == "black":
                    appliquer_theme("black", "white")
                else:
                    appliquer_theme("white", "black")
    except Exception as e:
        print(f"Erreur lors du chargement du thème: {e}")
        appliquer_theme("white", "black")

def get_current_theme():
    """Récupère le thème actuel du fichier de config"""
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                config = json.load(f)
                return config.get("theme", "white")
    except:
        pass
    return "white"

def apply_theme_to_window(window):
    """Applique le thème actuel à une fenêtre"""
    theme = get_current_theme()
    if theme == "black":
        window.configure(bg="black")
    else:
        window.configure(bg="white")

def configuration_them():

    label_1 = tk.Label(
        ui,
        text="Configuration",
        font=("Arial", 24),
        bg=ui["bg"],
        fg="black"
    )
    label_1.pack(pady=20)


    label_2 = tk.Label(
        ui,
        text="Veuillez sélectionner un thème",
        font=("Arial", 16),
        bg=ui["bg"],
        fg="black"
    )
    label_2.pack(pady=10)


    btn_black = tk.Button(
        ui,
        text="Thème Noir",
        font=("Arial", 14),
        command=set_theme_black
    )
    btn_black.pack(pady=5)


    btn_white = tk.Button(
        ui,
        text="Thème Blanc",
        font=("Arial", 14),
        command=set_theme_white
    )
    btn_white.pack(pady=5)


    widgets_theme.extend([
        label_1,
        label_2,
        btn_black,
        btn_white
    ])
    btn14 = tk.Button(ui, text="continuer", command=steam_configuration)
    btn14.pack(pady=20)
def demarer_steam():
    steam_path = find_steam()
    steam_exe = os.path.join(steam_path, "Steam.exe")

    if os.path.exists(steam_exe):
        os.startfile(steam_exe)
        print("steam demarer")
    else:
        print("le fichier Steam.exe n'existe pas dans le chemin spécifié")

def fermer_steam():
    os.system("taskkill /f /im steam.exe")
    print("steam ferme")

def fin_config():
    import subprocess
    import sys

    subprocess.Popen([sys.executable, "main.py"])
    sys.exit()


def injection():
    fenetre2 = tk.Toplevel(ui)
    fenetre2.title("injection")
    fenetre2.geometry("900x900")
    apply_theme_to_window(fenetre2)
    inject_label = tk.Label(fenetre2, text="injection des dll en cours ",font=("Arial", 14))
    inject_label.pack(pady=20)
    injector()
    aze = tk.Label(fenetre2, text="injection termine" ,font=("Arial", 14))
    aze.pack(pady=20)
    btn_continuer = tk.Button(fenetre2, text="continuer", command=lambda: (fermer_steam(), fin_config()))
    btn_continuer.pack(pady=20)


def steam_configuration():
    ui.withdraw()
    fenetre1 = tk.Toplevel()
    fenetre1.title("steam_configuration")
    fenetre1.geometry("900x900")
    apply_theme_to_window(fenetre1)
    
    steam_path = find_steam()
    
    # Titre
    title = tk.Label(fenetre1, text="Configuration Steam", font=("Arial", 20, "bold"))
    title.pack(pady=20)
    
    if steam_path:
        # Steam trouvé - afficher le chemin
        status = tk.Label(fenetre1, text="✓ Steam détecté", fg="green", font=("Arial", 12, "bold"))
        status.pack(pady=10)
        
        fenlab = tk.Label(fenetre1, text=f"Chemin: {steam_path}", font=("Arial", 12), wraplength=800)
        fenlab.pack(pady=10)
        
        # Vérifier si le chemin existe
        if os.path.exists(steam_path):
            valid = tk.Label(fenetre1, text="✓ Chemin valide", fg="green", font=("Arial", 10))
            valid.pack(pady=5)
        else:
            valid = tk.Label(fenetre1, text="✗ Chemin invalide", fg="red", font=("Arial", 10))
            valid.pack(pady=5)
        
        # Bouton pour continuer
        def continuer():
            save_config(steam_path)
            fenetre1.destroy()
            injection()
            
        
        btn_continuer = tk.Button(fenetre1, text="Continuer", command=continuer, font=("Arial", 12), bg="green", fg="white")
        btn_continuer.pack(pady=20)
    else:
        # Steam non trouvé
        status = tk.Label(fenetre1, text="✗ Steam non trouvé", fg="red", font=("Arial", 12, "bold"))
        status.pack(pady=10)
        
        info = tk.Label(fenetre1, text="Le chemin Steam n'a pas pu être détecté automatiquement.\nVeuillez entrer le chemin manuellement.", font=("Arial", 10), wraplength=800)
        info.pack(pady=10)
        
        # Entry pour entrer le chemin manuellement
        entry = tk.Entry(fenetre1, font=("Arial", 10), width=60)
        entry.pack(pady=10)
        
        def continuer_manuel():
            path = entry.get()
            if path and os.path.exists(path):
                save_config(path)
                fenetre1.destroy()
                ui.deiconify()
            else:
                error = tk.Label(fenetre1, text="Chemin invalide", fg="red", font=("Arial", 10))
                error.pack()
        
        btn_continuer = tk.Button(fenetre1, text="Continuer", command=continuer_manuel, font=("Arial", 12), bg="blue", fg="white")
        btn_continuer.pack(pady=20)



    
configuration_them()

ui.mainloop()