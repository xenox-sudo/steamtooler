import tkinter as tk
from tkinter import messagebox
import os
import sys
import json
import webbrowser
import threading

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(ROOT)

from core.detect_steam_installation import find_steam
from core.appid_download import download_appid, save_appid


# ==========================
# THEME
# ==========================

BG_COLOR = "#1e1e2e"
FG_COLOR = "#cdd6f4"
ACCENT_COLOR = "#89b4fa"
SUCCESS_COLOR = "#a6e3a1"
ERROR_COLOR = "#f38ba8"


CONFIG_FILE = os.path.join(
    ROOT,
    "config",
    "config.json"
)



# ==========================
# CONFIG
# ==========================

def load_config():

    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)

    except:
        return {}



# ==========================
# UI
# ==========================

class SteamToolerUI:

    def __init__(self, root):

        self.root = root

        self.root.title(
            "SteamTooler 2.0"
        )

        self.root.geometry(
            "1000x700"
        )

        self.root.resizable(
            False,
            False
        )

        self.root.configure(
            bg=BG_COLOR
        )


        self.load_theme()

        self.create_menu()

        self.create_main()



    # ======================
    # THEME
    # ======================

    def load_theme(self):

        global BG_COLOR, FG_COLOR, ACCENT_COLOR

        config = load_config()

        if config.get("theme") == "white":

            BG_COLOR = "#ffffff"
            FG_COLOR = "#000000"
            ACCENT_COLOR = "#0078d4"

            self.root.configure(
                bg=BG_COLOR
            )



    # ======================
    # MENU
    # ======================

    def create_menu(self):

        bar = tk.Frame(
            self.root,
            bg=ACCENT_COLOR,
            height=50
        )

        bar.pack(
            fill="x"
        )


        tk.Label(
            bar,
            text="⚙️ SteamTooler 2.0",
            font=("Segoe UI",16,"bold"),
            bg=ACCENT_COLOR,
            fg="white"
        ).pack(
            side="left",
            padx=20
        )


        tk.Button(
            bar,
            text="ℹ️ À propos",
            bg=ACCENT_COLOR,
            fg="white",
            border=0,
            command=self.about
        ).pack(
            side="right",
            padx=10
        )


        tk.Button(
            bar,
            text="⚙️ Paramètres",
            bg=ACCENT_COLOR,
            fg="white",
            border=0,
            command=self.settings
        ).pack(
            side="right"
        )



    # ======================
    # MAIN
    # ======================

    def create_main(self):

        frame = tk.Frame(
            self.root,
            bg=BG_COLOR
        )

        frame.pack(
            expand=True,
            fill="both"
        )


        tk.Label(
            frame,
            text="Bienvenue dans SteamTooler",
            font=("Segoe UI",28,"bold"),
            bg=BG_COLOR,
            fg=FG_COLOR
        ).pack(
            pady=30
        )


        tk.Label(
            frame,
            text="Entrez un AppID Steam",
            font=("Segoe UI",12),
            bg=BG_COLOR,
            fg=ACCENT_COLOR
        ).pack()



        self.appid_entry = tk.Entry(
            frame,
            font=("Segoe UI",16),
            width=25,
            bg="#2a2a3e",
            fg="white",
            insertbackground="white"
        )

        self.appid_entry.pack(
            pady=20
        )


        self.appid_entry.bind(
            "<Return>",
            lambda e:self.download()
        )



        self.info_label = tk.Label(
            frame,
            text="",
            bg=BG_COLOR,
            fg=ACCENT_COLOR,
            font=("Segoe UI",10)
        )

        self.info_label.pack()



        buttons = tk.Frame(
            frame,
            bg=BG_COLOR
        )

        buttons.pack(
            side="bottom",
            pady=30
        )



        self.make_button(
            buttons,
            "🔧 Fix",
            self.fix,
            ERROR_COLOR
        )


        self.make_button(
            buttons,
            "🌐 Online",
            self.online,
            SUCCESS_COLOR
        )


        self.make_button(
            buttons,
            "⬇ Télécharger",
            self.download,
            ACCENT_COLOR
        )



    def make_button(self,parent,text,cmd,color):

        tk.Button(
            parent,
            text=text,
            width=18,
            height=2,
            font=("Segoe UI",12,"bold"),
            bg=color,
            fg="black",
            border=0,
            command=cmd
        ).pack(
            side="left",
            padx=10
        )



    # ======================
    # DOWNLOAD
    # ======================

    def download(self):

        appid = self.appid_entry.get().strip()


        if not appid.isdigit():

            self.info_label.config(
                text="❌ AppID invalide",
                fg=ERROR_COLOR
            )

            return


        self.info_label.config(
            text="⏳ Téléchargement...",
            fg=ACCENT_COLOR
        )


        threading.Thread(
            target=self.download_thread,
            args=(appid,),
            daemon=True
        ).start()



    def download_thread(self,appid):

        try:

            save_appid(appid)

            file = download_appid(appid)


            self.info_label.config(
                text=f"✓ Terminé : {file}",
                fg=SUCCESS_COLOR
            )


        except Exception as e:

            self.info_label.config(
                text=f"❌ {e}",
                fg=ERROR_COLOR
            )



    # ======================
    # OLD BUTTONS
    # ======================

    def fix(self):

        self.info_label.config(
            text="🔧 Mode Fix lancé",
            fg=ACCENT_COLOR
        )


    def online(self):

        appid=self.appid_entry.get().strip()

        if appid.isdigit():

            webbrowser.open(
                f"https://steamdb.info/app/{appid}/"
            )


    # ======================
    # WINDOWS
    # ======================

    def settings(self):

        win=tk.Toplevel(self.root)

        win.title("Paramètres")
        win.geometry("400x300")
        win.configure(bg=BG_COLOR)


        tk.Label(
            win,
            text=f"Steam : {find_steam() or 'Non trouvé'}",
            bg=BG_COLOR,
            fg=FG_COLOR,
            wraplength=350
        ).pack(
            pady=40
        )



    def about(self):

        messagebox.showinfo(
            "SteamTooler",
            "SteamTooler 2.0\nVersion 2.0.0"
        )



# ==========================
# START
# ==========================

if __name__ == "__main__":

    root=tk.Tk()

    app=SteamToolerUI(root)

    root.mainloop()