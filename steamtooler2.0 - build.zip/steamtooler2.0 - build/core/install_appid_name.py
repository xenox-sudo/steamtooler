import os, json, tkinter as tk, webbrowser
from tkinter import messagebox

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG = os.path.join(ROOT, "config", "config.json")


def load():
    if os.path.exists(CONFIG):
        try:
            with open(CONFIG, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {}


def save_api(api):
    os.makedirs(os.path.dirname(CONFIG), exist_ok=True)

    data = load()
    data["api"] = api

    with open(CONFIG, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)


def main():
    root = tk.Tk()
    root.title("SteamTooler - API")
    root.geometry("600x350")
    root.configure(bg="#111111")
    root.resizable(False, False)

    tk.Label(
        root,
        text="Configuration API Ryuu",
        font=("Segoe UI", 18, "bold"),
        fg="#00ff88",
        bg="#111111"
    ).pack(pady=20)

    tk.Label(
        root,
        text="Collez votre API ci-dessous puis sauvegardez.",
        fg="white",
        bg="#111111"
    ).pack()

    entry = tk.Entry(
        root,
        width=45,
        bg="#222222",
        fg="white",
        insertbackground="white"
    )
    entry.pack(pady=20)

    old = load().get("api")
    if old:
        entry.insert(0, old)


    tk.Button(
        root,
        text="Ouvrir Ryuu",
        width=20,
        command=lambda: webbrowser.open(
            "https://generator.ryuu.lol/api"
        )
    ).pack(pady=5)


    def save():
        api = entry.get().strip()

        if not api:
            messagebox.showerror(
                "Erreur",
                "API vide"
            )
            return

        save_api(api)

        messagebox.showinfo(
            "OK",
            "API sauvegardée"
        )


    tk.Button(
        root,
        text="Sauvegarder",
        width=20,
        command=save
    ).pack(pady=10)

    root.mainloop()


if __name__ == "__main__":
    main()