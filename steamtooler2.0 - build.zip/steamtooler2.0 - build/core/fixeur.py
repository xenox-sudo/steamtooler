import os
import datetime
import requests
import tkinter as tk

from tkinter import ttk, messagebox
from urllib.parse import quote


# ==========================
# PATH
# ==========================

ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


DOWNLOAD_FOLDER = os.path.join(
    ROOT,
    "game",
    "downloads"
)


LOG_FILE = os.path.join(
    ROOT,
    "fixeur.log"
)


os.makedirs(
    DOWNLOAD_FOLDER,
    exist_ok=True
)



# ==========================
# CONFIG
# ==========================

BASE_URL = "https://generator.ryuu.lol/fixes/"



# ==========================
# LOG
# ==========================

def log(message, level="INFO"):

    heure = datetime.datetime.now().strftime(
        "%H:%M:%S"
    )

    text = (
        f"[{heure}] [{level}] {message}"
    )

    print(text)

    with open(
        LOG_FILE,
        "a",
        encoding="utf-8"
    ) as f:

        f.write(
            text + "\n"
        )



# ==========================
# URL
# ==========================

def create_url(name):

    if not name.endswith(".zip"):
        name += ".zip"


    encoded = quote(name)


    url = BASE_URL + encoded


    log(
        f"URL créée : {url}"
    )


    return url



# ==========================
# DOWNLOAD
# ==========================

def download_file(url, filename):

    destination = os.path.join(
        DOWNLOAD_FOLDER,
        filename
    )


    log(
        f"Téléchargement vers : {destination}"
    )


    headers = {

        "User-Agent":
        (
            "Mozilla/5.0 "
            "(Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 "
            "Chrome/120 Safari/537.36"
        ),

        "Referer":
        "https://generator.ryuu.lol/"
    }



    try:

        response = requests.get(
            url,
            headers=headers,
            stream=True,
            timeout=30
        )


        log(
            f"HTTP : {response.status_code}"
        )


        if response.status_code != 200:

            raise Exception(
                f"Erreur HTTP {response.status_code}"
            )



        total = int(
            response.headers.get(
                "content-length",
                0
            )
        )


        actuel = 0



        with open(
            destination,
            "wb"
        ) as file:


            for chunk in response.iter_content(
                chunk_size=8192
            ):


                if chunk:

                    file.write(
                        chunk
                    )


                    actuel += len(chunk)



                    if total:

                        pourcentage = (
                            actuel * 100
                        ) / total


                        progress["value"] = pourcentage


                        status.config(
                            text=f"Téléchargement {int(pourcentage)}%"
                        )


                        window.update_idletasks()



        log(
            "Téléchargement terminé",
            "OK"
        )


        status.config(
            text="Terminé"
        )


        messagebox.showinfo(
            "Succès",
            "Fichier téléchargé"
        )



    except Exception as e:


        log(
            str(e),
            "ERROR"
        )


        messagebox.showerror(
            "Erreur",
            str(e)
        )



# ==========================
# START
# ==========================

def start():

    name = entry.get().strip()


    if not name:

        messagebox.showwarning(
            "Erreur",
            "Entre un nom de fichier"
        )

        return



    if not name.endswith(".zip"):

        filename = name + ".zip"

    else:

        filename = name



    log(
        f"Recherche : {filename}"
    )


    url = create_url(
        filename
    )


    link.config(
        text=url
    )


    download_file(
        url,
        filename
    )



# ==========================
# UI
# ==========================

window = tk.Tk()

window.title(
    "Fixeur Downloader"
)

window.geometry(
    "650x420"
)



log(
    "Application lancée"
)



title = tk.Label(
    window,
    text="Fixeur Downloader",
    font=(
        "Arial",
        18,
        "bold"
    )
)

title.pack(
    pady=20
)



entry = ttk.Entry(
    window,
    width=50
)

entry.pack()



button = ttk.Button(
    window,
    text="Télécharger",
    command=start
)

button.pack(
    pady=15
)



link = tk.Label(
    window,
    text="Lien généré",
    wraplength=600
)

link.pack()



status = tk.Label(
    window,
    text="Prêt"
)

status.pack(
    pady=10
)



progress = ttk.Progressbar(
    window,
    length=500,
    mode="determinate"
)

progress.pack(
    pady=10
)



window.mainloop()