import os
import json
import zipfile
import shutil
import tkinter as tk
from tkinter import messagebox


# ==========================
# PATHS
# ==========================

ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

ZIP_FOLDER = os.path.join(
    ROOT,
    "game",
    "zip"
)

UNZIP_FOLDER = os.path.join(
    ROOT,
    "game",
    "unzip"
)

CONFIG_FOLDER = os.path.join(
    ROOT,
    "config"
)

CONFIG_FILE = os.path.join(
    CONFIG_FOLDER,
    "config.json"
)

HISTORY_FILE = os.path.join(
    CONFIG_FOLDER,
    "history.json"
)


os.makedirs(
    CONFIG_FOLDER,
    exist_ok=True
)



# ==========================
# CONFIG
# ==========================

def get_steam_path():

    if not os.path.exists(CONFIG_FILE):
        return None


    with open(
        CONFIG_FILE,
        "r",
        encoding="utf-8"
    ) as f:

        data = json.load(f)


    return data.get(
        "steam_path"
    )



# ==========================
# HISTORY
# ==========================

def load_history():

    if not os.path.exists(HISTORY_FILE):

        return []


    with open(
        HISTORY_FILE,
        "r",
        encoding="utf-8"
    ) as f:

        return json.load(f)



def save_history(history):

    with open(
        HISTORY_FILE,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            history,
            f,
            indent=4
        )



def already_installed(zip_name):

    history = load_history()

    return zip_name in history



# ==========================
# ZIP
# ==========================

def get_zips():

    if not os.path.exists(ZIP_FOLDER):

        return []


    return [
        file
        for file in os.listdir(ZIP_FOLDER)
        if file.lower().endswith(".zip")
    ]



def extract_zip(zip_name):

    zip_path = os.path.join(
        ZIP_FOLDER,
        zip_name
    )


    if os.path.exists(UNZIP_FOLDER):

        shutil.rmtree(
            UNZIP_FOLDER
        )


    os.makedirs(
        UNZIP_FOLDER,
        exist_ok=True
    )


    with zipfile.ZipFile(
        zip_path,
        "r"
    ) as zip_file:

        zip_file.extractall(
            UNZIP_FOLDER
        )



# ==========================
# MOVE FILES
# ==========================

def move_files():

    steam = get_steam_path()


    if not steam:

        raise Exception(
            "Steam non configuré"
        )


    lua_folder = os.path.join(
        steam,
        "config",
        "lua"
    )


    manifest_folder = os.path.join(
        steam,
        "config",
        "manifest"
    )


    os.makedirs(
        lua_folder,
        exist_ok=True
    )


    os.makedirs(
        manifest_folder,
        exist_ok=True
    )


    lua_count = 0
    manifest_count = 0



    for root, dirs, files in os.walk(
        UNZIP_FOLDER
    ):

        for file in files:

            source = os.path.join(
                root,
                file
            )


            if file.lower().endswith(".lua"):

                shutil.move(
                    source,
                    os.path.join(
                        lua_folder,
                        file
                    )
                )

                lua_count += 1



            elif file.lower().endswith(".manifest"):

                shutil.move(
                    source,
                    os.path.join(
                        manifest_folder,
                        file
                    )
                )

                manifest_count += 1



    return lua_count, manifest_count



# ==========================
# INSTALLATION
# ==========================

def install(zip_name):


    if already_installed(zip_name):

        messagebox.showwarning(
            "Bloqué",
            "Ce fichier a déjà été installé."
        )

        return



    try:

        extract_zip(
            zip_name
        )


        lua, manifest = move_files()


        history = load_history()

        history.append(
            zip_name
        )

        save_history(
            history
        )


        messagebox.showinfo(
            "Terminé",
            f"Installation réussie\n\n"
            f"Lua : {lua}\n"
            f"Manifest : {manifest}"
        )


    except Exception as e:

        messagebox.showerror(
            "Erreur",
            str(e)
        )



# ==========================
# UI
# ==========================

def start_ui():

    app = tk.Tk()

    app.title(
        "SteamTooler Blaster"
    )

    app.geometry(
        "450x400"
    )


    title = tk.Label(
        app,
        text="Sélection du fichier ZIP",
        font=("Arial", 15)
    )

    title.pack(
        pady=15
    )


    box = tk.Listbox(
        app,
        font=("Arial", 12)
    )

    box.pack(
        expand=True,
        fill="both",
        padx=30
    )


    zips = get_zips()


    history = load_history()



    for zip_file in zips:

        if zip_file in history:

            box.insert(
                "end",
                zip_file + "  [déjà utilisé]"
            )

        else:

            box.insert(
                "end",
                zip_file
            )

    def restart_steam():
        os.system("taskkill /f /im steam.exe")
        os.startfile("steam://open/main")

    def launch():

        selected = box.curselection()

        if not selected:
            return


        install(
            zips[selected[0]]
        )


    button = tk.Button(
        app,
        text="Installer",
        command=launch,
        height=2
    )

    button.pack(
        pady=15
    )

    restart_steam()
    app.mainloop()



# ==========================
# START
# ==========================

if __name__ == "__main__":

    start_ui()