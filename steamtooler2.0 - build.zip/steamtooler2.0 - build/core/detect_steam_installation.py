import os
import json
import winreg


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_DIR = os.path.join(ROOT, "config")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

os.makedirs(CONFIG_DIR, exist_ok=True)


def find_steam():
    try:
        key = winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\WOW6432Node\Valve\Steam"
        )

        path, _ = winreg.QueryValueEx(key, "InstallPath")
        return path

    except:
        return None


def save_config(steam_path):
    data = {}

    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

    data["steam_path"] = steam_path

    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)


steam = find_steam()

if steam:
    save_config(steam)
    print("steam trouvé")
    print("Steam enregistré :", steam)
else:
    print("Steam introuvable")