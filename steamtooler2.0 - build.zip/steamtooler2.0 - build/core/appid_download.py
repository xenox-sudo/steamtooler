import os
import json
import requests


ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

CONFIG_FILE = os.path.join(
    ROOT,
    "config",
    "config.json"
)

DOWNLOAD_DIR = os.path.join(
    ROOT,
    "game",
    "zip"
)


API_URL = "https://generator.ryuu.lol/api/download"



def load_config():

    if not os.path.exists(CONFIG_FILE):
        return {}

    with open(
        CONFIG_FILE,
        "r",
        encoding="utf-8"
    ) as f:
        return json.load(f)



def save_appid(appid):

    config = load_config()

    config["appid"] = appid

    with open(
        CONFIG_FILE,
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            config,
            f,
            indent=4
        )



def download_appid(appid):

    config = load_config()

    api = config.get("api")

    if not api:
        raise Exception(
            "API absente dans config.json"
        )


    os.makedirs(
        DOWNLOAD_DIR,
        exist_ok=True
    )


    url = f"{API_URL}/{appid}"


    params = {
        "file_type": "manifest"
    }


    headers = {
        "X-Auth-Key": api
    }


    response = requests.get(
        url,
        headers=headers,
        params=params,
        stream=True,
        timeout=120
    )


    if response.status_code != 200:
        raise Exception(
            f"Erreur serveur : {response.status_code}"
        )


    file_path = os.path.join(
        DOWNLOAD_DIR,
        f"{appid}.zip"
    )


    with open(
        file_path,
        "wb"
    ) as f:

        for chunk in response.iter_content(
            chunk_size=8192
        ):

            if chunk:
                f.write(chunk)


    return file_path