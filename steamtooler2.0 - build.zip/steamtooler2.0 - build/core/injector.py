import zipfile
import os
import shutil

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DLL_PATH = os.path.join(BASE_DIR, "dll")
ZIP_PATH = os.path.join(BASE_DIR, "dep", "opensteamtool.zip")


def extract_only_dll(zip_path, extract_to):

    # Extraction temporaire
    temp = os.path.join(extract_to, "temp_extract")

    if os.path.exists(temp):
        shutil.rmtree(temp)

    os.makedirs(temp, exist_ok=True)

    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(temp)

    # Garder uniquement les DLL
    for root, dirs, files in os.walk(temp):
        for file in files:
            if file.lower().endswith(".dll"):
                source = os.path.join(root, file)
                destination = os.path.join(extract_to, file)

                shutil.move(source, destination)

    # Suppression définitive du reste
    shutil.rmtree(temp)


def injector():
    print("Extraction DLL...")

    if not os.path.exists(DLL_PATH):
        os.makedirs(DLL_PATH)

    extract_only_dll(ZIP_PATH, DLL_PATH)

    print("Terminé")


if __name__ == "__main__":
    injector()