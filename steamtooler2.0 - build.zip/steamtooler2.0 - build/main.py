import os
import sys
import json
import subprocess
from datetime import datetime


# ==========================
# PATHS
# ==========================

ROOT = os.path.dirname(os.path.abspath(__file__))

CONFIG_FILE = os.path.join(
    ROOT,
    "config",
    "config.json"
)

CONFIG_UI = os.path.join(
    ROOT,
    "ui",
    "configuration_ui.py"
)

API_SETUP = os.path.join(
    ROOT,
    "core",
    "install_appid_name.py"
)

MAIN_UI = os.path.join(
    ROOT,
    "ui",
    "main_ui.py"
)


# ==========================
# LOG
# ==========================

def log(message, level="INFO"):

    time = datetime.now().strftime("%H:%M:%S")

    print(
        f"[{time}] [{level}] {message}"
    )


# ==========================
# CONFIG
# ==========================

def load_config():

    if not os.path.isfile(CONFIG_FILE):
        return {}

    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as file:
            return json.load(file)

    except Exception:

        log(
            "Impossible de lire config.json",
            "ERROR"
        )

        return {}



def run_script(path, name):

    if not os.path.isfile(path):

        log(
            f"{name} introuvable",
            "ERROR"
        )

        return False


    log(
        f"Lancement {name}"
    )

    try:

        subprocess.run(
            [
                sys.executable,
                path
            ],
            cwd=ROOT
        )

        return True


    except Exception as e:

        log(
            f"Erreur lancement {name}: {e}",
            "ERROR"
        )

        return False



# ==========================
# CHECK
# ==========================

def verify_configuration():

    config = load_config()


    # Configuration générale

    if (
        not config.get("theme")
        or not config.get("steam_path")
    ):

        log(
            "Configuration manquante"
        )

        run_script(
            CONFIG_UI,
            "configuration_ui.py"
        )


        config = load_config()



    if (
        not config.get("theme")
        or not config.get("steam_path")
    ):

        log(
            "Configuration invalide",
            "ERROR"
        )

        return False



    log(
        "Configuration : OK"
    )



    # API

    if not config.get("api"):

        log(
            "API absente"
        )

        run_script(
            API_SETUP,
            "install_appid_name.py"
        )


        config = load_config()



    if not config.get("api"):

        log(
            "API absente après configuration",
            "ERROR"
        )

        return False



    log(
        "API : OK"
    )


    return True



# ==========================
# START
# ==========================

def start():

    print(
        "\n=============================="
    )

    print(
        "        STEAMTOOLER 2.0"
    )

    print(
        "==============================\n"
    )


    log(
        "Démarrage"
    )


    if verify_configuration():


        log(
            "Tous les tests sont validés"
        )


        run_script(
            MAIN_UI,
            "Interface principale"
        )


    else:

        log(
            "Impossible de démarrer SteamTooler",
            "ERROR"
        )



if __name__ == "__main__":
    start()